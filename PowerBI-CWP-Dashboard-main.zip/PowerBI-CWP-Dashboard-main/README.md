# PowerBI-CWP-Dashboard
A repo for downloading the custom_reporting.exe tool

Windows Instructions:

Set the environmental variables for your PRISMA_ACCESS_KEY AND PRISMA_SECRET_KEY

Running the tool via cmd or PowerShell:
./custom-reporting.exe -de -f C:/path -p "api.prismacloud.io"
